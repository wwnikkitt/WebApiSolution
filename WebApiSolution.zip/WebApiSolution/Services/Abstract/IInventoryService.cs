﻿using System;
using System.Collections.Generic;
using System.Text;
using Services.Dtos;

namespace Services.Abstract
{
    public interface IInventoryService
    {
        List<ProductDto> GetProducts();
        List<ProductDto> GetProductsAbovePrice(decimal price);
        void AddProduct(CreateProductDto product);
        bool UpdateProduct(int id, CreateProductDto product);
        bool DeleteProduct(int id);

        List<ProductDto> SearchByName(string name);
        List<ProductDto> GetBySupplier(int supplierId);
    }
}
