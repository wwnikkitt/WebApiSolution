﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Dtos;

public record SupplierDto(int Id, string Name, string Address);

