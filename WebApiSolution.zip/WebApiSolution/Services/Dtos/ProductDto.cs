﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Dtos;

public record ProductDto(int Id, string Name, decimal Price, int Stock, SupplierDto Supplier);

public record CreateProductDto(string Name, decimal Price, int Stock, int SupplierId);
