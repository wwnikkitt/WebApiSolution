﻿using Data.Context;
using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Services.Abstract;
using Services.Dtos;

namespace Services.Impl;

public class InventoryService : IInventoryService
{
    private readonly AppDbContext _context;

    // The DbContext is HANDED to us here (constructor injection)
    public InventoryService(AppDbContext context)
    {
        _context = context;
    }

    // Reusable query that turns Products (with their Supplier) into ProductDtos
    private IQueryable<ProductDto> ProductQuery()
    {
        return _context.Products
            .Include(p => p.Supplier)
            .Select(p => new ProductDto(
                p.Id, p.Name, p.Price, p.Stock,
                new SupplierDto(p.Supplier.Id, p.Supplier.Name, p.Supplier.Address)));
    }

    public List<ProductDto> GetProducts()
    {
        return ProductQuery().ToList();
    }

    public List<ProductDto> GetProductsAbovePrice(decimal price)
    {
        return ProductQuery().Where(p => p.Price > price).ToList();
    }

    public void AddProduct(CreateProductDto dto)
    {
        var product = new Product
        {
            Name = dto.Name,
            Price = dto.Price,
            Stock = dto.Stock,
            SupplierId = dto.SupplierId
        };

        _context.Products.Add(product);
        _context.SaveChanges();
    }

    public bool UpdateProduct(int id, CreateProductDto dto)
    {
        var product = _context.Products.FirstOrDefault(p => p.Id == id);
        if (product == null) return false;

        product.Name = dto.Name;
        product.Price = dto.Price;
        product.Stock = dto.Stock;
        product.SupplierId = dto.SupplierId;

        _context.SaveChanges();
        return true;
    }

    public bool DeleteProduct(int id)
    {
        var product = _context.Products.FirstOrDefault(p => p.Id == id);
        if (product == null) return false;

        _context.Products.Remove(product);
        _context.SaveChanges();
        return true;
    }

    public List<ProductDto> SearchByName(string name)
    {
        return ProductQuery().Where(p => p.Name.Contains(name)).ToList();
    }

    public List<ProductDto> GetBySupplier(int supplierId)
    {
        return ProductQuery().Where(p => p.Supplier.Id == supplierId).ToList();
    }
}