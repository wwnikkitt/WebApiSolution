﻿using Microsoft.AspNetCore.Mvc;
using Services.Abstract;
using Services.Dtos;
using Services.Impl;

namespace WebApi.Controllers;

[ApiController]
[Route("api/inventory")]
public class InventoryController : ControllerBase
{
    private readonly IInventoryService _service;

    public InventoryController(IInventoryService service)
    {
        _service = service;
    }

    // GET /api/inventory
    [HttpGet]
    public IActionResult GetProducts()
    {
        return Ok(_service.GetProducts());
    }

    // GET /api/inventory/above-price/{price}
    [HttpGet("above-price/{price}")]
    public IActionResult GetAbovePrice(decimal price)
    {
        return Ok(_service.GetProductsAbovePrice(price));
    }

    // POST /api/inventory
    [HttpPost]
    public IActionResult AddProduct(CreateProductDto product)
    {
        _service.AddProduct(product);
        return Ok();
    }

    // PUT /api/inventory/{id}
    [HttpPut("{id}")]
    public IActionResult UpdateProduct(int id, CreateProductDto product)
    {
        var updated = _service.UpdateProduct(id, product);
        if (!updated) return NotFound();
        return Ok();
    }

    // DELETE /api/inventory/{id}
    [HttpDelete("{id}")]
    public IActionResult DeleteProduct(int id)
    {
        var deleted = _service.DeleteProduct(id);
        if (!deleted) return NotFound();
        return Ok();
    }

    // ----- the 2 extra endpoints (required for In-Memory) -----

    // GET /api/inventory/search?name=...
    [HttpGet("search")]
    public IActionResult SearchByName([FromQuery] string name)
    {
        return Ok(_service.SearchByName(name));
    }

    // GET /api/inventory/by-supplier/{id}
    [HttpGet("by-supplier/{id}")]
    public IActionResult GetBySupplier(int id)
    {
        return Ok(_service.GetBySupplier(id));
    }
}