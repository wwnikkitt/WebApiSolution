using Data.Context;
using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Services.Abstract;
using Services.Impl;

var builder = WebApplication.CreateBuilder(args);

// --- 1. Register services into the DI container ---
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Use the In-Memory database (no SQL Server, no migrations)
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseInMemoryDatabase("InventoryDb"));

// Whenever someone asks for IInventoryService, give them an InventoryService
builder.Services.AddScoped<IInventoryService, InventoryService>();

var app = builder.Build();

// --- 2. Seed some starter data (In-Memory starts empty) ---
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

    var supplier1 = new Supplier { Name = "TechSupply", Address = "Tbilisi" };
    var supplier2 = new Supplier { Name = "FoodCorp", Address = "Batumi" };
    db.Suppliers.AddRange(supplier1, supplier2);

    db.Products.AddRange(
        new Product { Name = "Laptop", Price = 1500, Stock = 10, Supplier = supplier1 },
        new Product { Name = "Mouse", Price = 25, Stock = 100, Supplier = supplier1 },
        new Product { Name = "Coffee", Price = 8, Stock = 200, Supplier = supplier2 }
    );

    db.SaveChanges();
}

// --- 3. Configure the HTTP pipeline ---
app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();
app.Run();